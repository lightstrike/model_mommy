#coding:utf-8
__version__ = '1.2.3'
__title__ = 'model_mommy'
__author__ = 'Vanderson Mota'
__license__ = 'Apache 2.0'
